# Financial Cloud Platform (Simple Base Version)

A minimal REST API for cloud financial services: accounts, deposits, withdrawals, transfers and transaction history.

## Setup
```bash
pip install flask
python app.py
```
Optional environment variables: `FCP_API_KEY` (default `dev-secret-key`), `FCP_DB_PATH`, `PORT`.

## Quick test (all calls need the `X-API-Key` header)
```bash
H='-H X-API-Key:dev-secret-key -H Content-Type:application/json'

# create two accounts
curl $H -X POST localhost:5000/accounts -d '{"owner":"Alice"}'
curl $H -X POST localhost:5000/accounts -d '{"owner":"Bob"}'

# deposit, withdraw, transfer
curl $H -X POST localhost:5000/accounts/<ALICE_ID>/deposit  -d '{"amount":500}'
curl $H -X POST localhost:5000/accounts/<ALICE_ID>/withdraw -d '{"amount":50}'
curl $H -X POST localhost:5000/transfers -d '{"from":"<ALICE_ID>","to":"<BOB_ID>","amount":100}'

# history
curl $H localhost:5000/accounts/<ALICE_ID>/transactions
```

## Endpoints
| Method | Path | Purpose |
|---|---|---|
| GET | /health | Health check (no key needed) |
| POST | /accounts | Create account |
| GET | /accounts/{id} | Account details |
| POST | /accounts/{id}/deposit | Deposit |
| POST | /accounts/{id}/withdraw | Withdraw |
| POST | /transfers | Transfer between accounts |
| GET | /accounts/{id}/transactions | Transaction history |

## Next steps for a production cloud deployment
- Replace SQLite with PostgreSQL (e.g. AWS RDS / Azure / Cloud SQL)
- Replace the static API key with OAuth2/JWT and role-based access
- Add audit logging, encryption at rest, rate limiting and idempotency keys
- Containerise with Docker and deploy behind a load balancer
